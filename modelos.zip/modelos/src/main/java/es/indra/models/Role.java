package es.indra.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // getter, setter, equals, hashcode, toString
@NoArgsConstructor   // Constructor por defecto
@AllArgsConstructor  // Constructor completo
public class Role {

	private Long id;
	private String nombre;

	public Role(String nombre) {
		super();
		this.nombre = nombre;
	}

}
