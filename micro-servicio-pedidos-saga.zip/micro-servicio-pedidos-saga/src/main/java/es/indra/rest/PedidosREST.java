package es.indra.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.PedidosBSImplFeign;
import es.indra.models.Pedido;

@RestController
public class PedidosREST {

	// Tenemos 2 formas de resolver cuando hay mas de un bean de tipo IPedidoBS:
	// 1ª utilizar @Primary
	// 2ª utilizar el nombre de la clase
	private PedidosBSImplFeign bs;

	public PedidosREST(PedidosBSImplFeign bs) {
		super();
		this.bs = bs;
	}

	// http://localhost:8002/crear/3/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// Con Hystrix (try-catch) capturamos la excepcion y se deriba a un metodo alternativo
	// El problema es que si tenemos 50 operaciones en este servicio REST, Hystrix necesita 50 metodos alternativos
	// Por esa razon, se recomienda utilizar un Manejador de Excepciones Globales
	
	// http://localhost:8002/saga/descripcion/Mesa/precio/150/nombre/Antonio
	// http://localhost:8002/saga/descripcion/Silla/precio/98/nombre/Pepe
	@GetMapping("/saga/descripcion/{descripcion}/precio/{precio}/nombre/{nombre}")
	public String pruebaSaga(@PathVariable String descripcion, @PathVariable double precio, @PathVariable String nombre) {
		return bs.pruebaTransaccion(descripcion, precio, nombre);
	}

}
