package es.indra.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import feign.FeignException;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {
	
	// Igual que con try-catch podemos tener multiples catch
	// Aqui, podemos tener varios metodos que cada uno capture una excepcion distinta
	
	// http://localhost:8002/crear/46678765/cantidad/25
	@ExceptionHandler(FeignException.class)
	public ResponseEntity<String> errorValidacion(FeignException ex){
		return new ResponseEntity<String>("ID producto fuera de rango 1-6", HttpStatus.NOT_FOUND);
	}
	
	// http://localhost:8002/crear/ggvkhgvk/cantidad/25
	@ExceptionHandler(NumberFormatException.class)
	public ResponseEntity<String> errorIdTexto(NumberFormatException ex){
		return new ResponseEntity<String>("ID producto debe ser numerico", HttpStatus.BAD_REQUEST);
	}
}
