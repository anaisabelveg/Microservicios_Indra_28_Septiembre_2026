package es.indra.business;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
//@Primary
public class PedidosBSImplFeign implements IPedidosBS {

	private ProductosClienteFeign clienteFeign;

	public PedidosBSImplFeign(ProductosClienteFeign clienteFeign) {
		super();
		this.clienteFeign = clienteFeign;
	}

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

}
