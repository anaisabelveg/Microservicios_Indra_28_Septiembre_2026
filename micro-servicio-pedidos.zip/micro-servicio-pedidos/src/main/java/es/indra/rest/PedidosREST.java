package es.indra.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.PedidosBSImplFeign;
import es.indra.models.Pedido;

@RestController
public class PedidosREST {

	// Tenemos 2 formas de resolver cuando hay mas de un bean de tipo IPedidoBS:
	// 1ª utilizar @Primary
	// 2ª utilizar el nombre de la clase
	private PedidosBSImplFeign bs;

	public PedidosREST(PedidosBSImplFeign bs) {
		super();
		this.bs = bs;
	}

	// http://localhost:8002/crear/3/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}

}
