package es.indra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicioUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
