package es.indra.business;

import org.springframework.stereotype.Service;

@Service
public class ProveedoresBSImpl implements IProveedoresBS{

	@Override
	public String crearProveedor(String nombre) {
		
		if ("Pepe".equals(nombre)) {
			// Se produce un error que forzara el deshacer la Transaccion
			throw new RuntimeException("Transaccion cancelada por nombre Pepe");
		} else {
			// Todo va ok y se haria el commit de la transaccion
			return "Proveedor " + nombre + " creado con exito";
		}
		
	}

}
