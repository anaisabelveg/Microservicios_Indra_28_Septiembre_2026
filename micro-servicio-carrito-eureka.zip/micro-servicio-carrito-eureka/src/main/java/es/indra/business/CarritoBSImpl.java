package es.indra.business;

import java.util.List;

import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteFeign;
import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS {

	private CarritosDAO dao;
	private PedidosClienteFeign clienteFeign;

	public CarritoBSImpl(CarritosDAO dao, PedidosClienteFeign clienteFeign) {
		super();
		this.dao = dao;
		this.clienteFeign = clienteFeign;
	}

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = consultar(usuario);

		// No existe un carrito para ese usuario, lo creo
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}

		return carrito;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		// Crear el pedido
		Pedido pedido = clienteFeign.crear(id, cantidad);
		
		// Lo agregamos al carrito del usuario
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		
		// Modificar el importe del carrito
		double importePedido = pedido.getProducto().getPrecio() * cantidad;
		carrito.setImporte(importePedido + carrito.getImporte());
		
		// Actualizamos el carrito y lo retornamos
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		
		// Solo borro el primer pedido que encuentre con ese id de producto
		List<Pedido> contenido = carrito.getContenido();
		Pedido encontrado = contenido
								.stream()
								.filter(ped -> ped.getProducto().getID() == id)
								.findFirst()
								.get();
		contenido.remove(encontrado);
		
		// Si borramos la lista de los pedidos encontrados
		// contenido.removeAll(lista);
		
		// Modificar el importe del carrito
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		
		// Actualizamos el carrito y lo retornamos
		return dao.save(carrito);
	}

}
