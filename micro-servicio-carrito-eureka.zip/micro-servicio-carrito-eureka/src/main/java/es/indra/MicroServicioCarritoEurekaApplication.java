package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import es.indra.persistence.CarritosDAO;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
public class MicroServicioCarritoEurekaApplication implements CommandLineRunner{
	
	@Autowired
	private CarritosDAO dao;

	// En los proyectos de Spring Boot el metodo main esta dedicado exclusivamente a levantar el contexto de Spring
	// Aqui, no podemos meter mas codigo
	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoEurekaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Este metodo se ejecuta de forma automatica a continuacion del metodo main
		// Tengo asegurado que el bean dao ya ha sido inyectado
		
		// Elimino todos los carritos de MongoDB
		dao.deleteAll();
		
	}

}
