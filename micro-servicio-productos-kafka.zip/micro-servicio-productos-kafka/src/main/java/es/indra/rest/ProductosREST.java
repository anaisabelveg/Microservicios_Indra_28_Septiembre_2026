package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;
import es.indra.kafka.Productor;

@RestController // Es un bean de Spring
//@RequestMapping("/api")
@Validated  // Necesario para activar las reglas de validacion
public class ProductosREST {

	// Para inyectar este bean, 2 opciones:
	// 1ª poner la anotacion @Autowired
	// 2ª crear el constructor que recibe este bean como parametro
	private IProductosBS bs;
	private Productor productor;
	
	@Value("${server.port}")   // para inyectar valores (primitivos y String)
	private Integer port;

	public ProductosREST(IProductosBS bs, Productor productor) {
		super();
		this.bs = bs;
		this.productor = productor;
	}
	
	// http://localhost:8001/enviar/2/mensaje/Producto de buena calidad a precio asequible. Entrega rapida
	@GetMapping("/enviar/{id}/mensaje/{mensaje}")
	public void enviar(@PathVariable Long id, @PathVariable String mensaje) {
		Producto producto = bs.buscarProducto(id);
		String comentario = mensaje + " del producto " + producto;
		productor.enviarComentario(comentario);
	}

	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar() {
		return bs.consultarTodos()
					.stream()
					.map(prod -> {
						prod.setPort(port);
						return prod;
					})
					.collect(Collectors.toList());
	}

	// http://localhost:8001/buscar/4
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") @Min(1) @Max(6)  Long id) {
		Producto producto = bs.buscarProducto(id);
		
		// Si no ha encontrado el producto lanzamos una excepcion
		if (producto.getDescripcion() == null)
			throw new RuntimeException("Ese producto no existe");
		
		producto.setPort(port);
		return producto;
	}

}
