package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioProductosApplication {

	public static void main(String[] args) {
		// Levantar el contexto de Spring (crear los beans y guardarlos en el contenedor)
		// Escanea todos los paquetes que comienzan por es.indra para detectar los beans
		// es.indra porque es donde esta ubicada la clase con la anotacion @SpringBootApplication
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

}
